# Pics2Word

A command line program to copy pictures into a word document.